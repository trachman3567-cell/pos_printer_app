package com.example.posprinter.printer

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.UUID

class BluetoothPrinter(
    override val id: String,
    override val name: String,
    private val device: BluetoothDevice
) : Printer {
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override suspend fun connect(): Boolean = withContext(Dispatchers.IO) {
        try {
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket?.connect()
            out = socket?.outputStream
            true
        } catch (e: Exception) {
            e.printStackTrace()
            disconnect()
            false
        }
    }

    override suspend fun disconnect() = withContext(Dispatchers.IO) {
        try {
            out?.close()
            socket?.close()
        } catch (_: Exception) {}
        out = null; socket = null
    }

    override suspend fun printRaw(bytes: ByteArray): Boolean = withContext(Dispatchers.IO) {
        try {
            if (out == null) if (!connect()) return@withContext false
            out!!.write(bytes)
            out!!.flush()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            disconnect()
            false
        }
    }

    override suspend fun printReceipt(bytesList: List<ByteArray>): Boolean {
        val total = bytesList.fold(ByteArray(0)) { acc, b -> acc + b }
        return printRaw(total)
    }

    override suspend fun status(): PrinterStatus = withContext(Dispatchers.IO) {
        PrinterStatus(online = socket?.isConnected == true)
    }

    override suspend fun isConnected(): Boolean = socket?.isConnected == true
}
