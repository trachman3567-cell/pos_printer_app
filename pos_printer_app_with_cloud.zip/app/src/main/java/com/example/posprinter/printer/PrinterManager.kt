package com.example.posprinter.printer

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import android.content.SharedPreferences
import android.preference.PreferenceManager

class PrinterManager(private val context: Context) {
    private val printers = mutableMapOf<String, Printer>()
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val prefs: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

    fun registerPrinter(printer: Printer) {
        printers[printer.id] = printer
    }

    fun unregisterPrinter(id: String) {
        printers.remove(id)
    }

    fun getPrinter(id: String): Printer? = printers[id]

    fun listPrinters(): List<Printer> = printers.values.toList()

    fun enqueuePrint(printerId: String, parts: List<ByteArray>, kitchenMode: Boolean = false) {
        val p = printers[printerId] ?: return
        scope.launch {
            try {
                // If kitchen mode, do not send CUT command or logo
                val autoCut = prefs.getBoolean("pref_auto_cut", true)
                val sendParts = if (kitchenMode) parts.filterNot { isCutCommand(it) } else parts
                p.printReceipt(sendParts)
                // optionally log success
            } catch (e: Exception) {
                e.printStackTrace()
                // retry logic could be here
            }
        }
    }

    private fun isCutCommand(bytes: ByteArray): Boolean {
        if (bytes.size >= 3 && bytes[0] == 0x1D.toByte() && bytes[1] == 0x56.toByte()) return true
        return false
    }
}
