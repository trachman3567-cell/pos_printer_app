package com.example.posprinter

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.posprinter.viewmodel.PosViewModel
import com.example.posprinter.data.Product
import com.example.posprinter.data.CartItem
import kotlinx.coroutines.*
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.TextView as TV

class CashierActivity : AppCompatActivity() {
    private val vm: PosViewModel by viewModels()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var rvProducts: RecyclerView
    private lateinit var rvCart: RecyclerView
    private lateinit var tvTotal: TextView
    private val cartAdapter = CartAdapter()
    private val productAdapter = ProductAdapter { product -> vm.addToCart(product) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cashier)
        rvProducts = findViewById(R.id.rv_products)
        rvCart = findViewById(R.id.rv_cart)
        tvTotal = findViewById(R.id.tv_total)
        val btnClear = findViewById<Button>(R.id.btn_clear)
        val btnPay = findViewById<Button>(R.id.btn_pay)
        val btnOpen = findViewById<Button>(R.id.btn_open_drawer)

        rvProducts.layoutManager = LinearLayoutManager(this)
        rvProducts.adapter = productAdapter

        rvCart.layoutManager = LinearLayoutManager(this)
        rvCart.adapter = cartAdapter

        vm.seedSample()

        scope.launch {
            vm.products.collect { list ->
                productAdapter.submitList(list)
            }
        }

        // refresh cart periodically
        scope.launch {
            while (isActive) {
                val items = vm.getCart()
                cartAdapter.submitList(items)
                val total = items.sumOf { it.price * it.qty }
                tvTotal.text = "Total: " + total
                delay(1000)
            }
        }

        btnClear.setOnClickListener {
            vm.clearCart()
        }

        btnPay.setOnClickListener {
            val intent = Intent(this, PaymentActivity::class.java)
            startActivity(intent)
        }

        btnOpen.setOnClickListener {
            // open drawer via printer TCP command using sample ip stored in preferences (for demo use 192.168.1.50)
            scope.launch {
                val ip = "192.168.1.50"
                val printer = com.example.posprinter.printer.RawTcpPrinter("drawer", "drawer", ip, 9100)
                if (printer.connect()) {
                    printer.printRaw(com.example.posprinter.printer.EscPos.DRAWER)
                    printer.disconnect()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}

class ProductAdapter(val onClick: (Product)->Unit) : androidx.recyclerview.widget.ListAdapter<Product, ProductViewHolder>(object: androidx.recyclerview.widget.DiffUtil.ItemCallback<Product>() {
    override fun areItemsTheSame(oldItem: Product, newItem: Product) = oldItem.id==newItem.id
    override fun areContentsTheSame(oldItem: Product, newItem: Product) = oldItem==newItem
}) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(v)
    }
    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val p = getItem(position)
        holder.name.text = p.name
        holder.price.text = p.price.toString()
        holder.itemView.setOnClickListener { onClick(p) }
    }
}
class ProductViewHolder(v: View): RecyclerView.ViewHolder(v) {
    val name: TV = v.findViewById(R.id.tv_name)
    val price: TV = v.findViewById(R.id.tv_price)
}

class CartAdapter : androidx.recyclerview.widget.ListAdapter<CartItem, CartViewHolder>(object: androidx.recyclerview.widget.DiffUtil.ItemCallback<CartItem>() {
    override fun areItemsTheSame(oldItem: CartItem, newItem: CartItem) = oldItem.id==newItem.id
    override fun areContentsTheSame(oldItem: CartItem, newItem: CartItem) = oldItem==newItem
}) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(v)
    }
    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val c = getItem(position)
        holder.name.text = c.name
        holder.qty.text = c.qty.toString()
        holder.price.text = (c.price * c.qty).toString()
    }
}
class CartViewHolder(v: View): RecyclerView.ViewHolder(v) {
    val name: TV = v.findViewById(R.id.tv_cart_name)
    val qty: TV = v.findViewById(R.id.tv_cart_qty)
    val price: TV = v.findViewById(R.id.tv_cart_price)
}
