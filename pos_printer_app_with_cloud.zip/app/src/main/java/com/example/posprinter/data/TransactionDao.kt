package com.example.posprinter.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TransactionDao {
    @Insert
    suspend fun insert(tx: TransactionEntity)

    @Query("SELECT * FROM transactions ORDER BY datetime DESC")
    suspend fun all(): List<TransactionEntity>
}
