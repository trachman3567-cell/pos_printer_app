package com.example.posprinter.printer

object EscPos {
    val INIT = byteArrayOf(0x1B, 0x40)
    val LF = byteArrayOf(0x0A)
    val CUT = byteArrayOf(0x1D, 0x56, 0x00)
    val DRAWER = byteArrayOf(0x1B, 0x70, 0x00, 0x3C, 0xFF.toByte())

    fun text(s: String) = s.toByteArray(Charsets.UTF_8)
    fun alignCenter() = byteArrayOf(0x1B, 0x61, 0x01)
    fun alignLeft() = byteArrayOf(0x1B, 0x61, 0x00)
    fun boldOn() = byteArrayOf(0x1B, 0x45, 0x01)
    fun boldOff() = byteArrayOf(0x1B, 0x45, 0x00)
}
