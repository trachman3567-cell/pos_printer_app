package com.example.posprinter.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.posprinter.data.Product
import com.example.posprinter.data.CartItem
import com.example.posprinter.data.TransactionEntity
import com.example.posprinter.repo.PosRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.google.gson.Gson

class PosViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = PosRepository(app)
    val products = repo.products.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<Product>())

    fun seedSample() {
        viewModelScope.launch {
            repo.addProduct(Product(sku="P001", name="Nasi Goreng", price=15000))
            repo.addProduct(Product(sku="P002", name="Es Teh", price=5000))
            repo.addProduct(Product(sku="P003", name="Kopi Hitam", price=10000))
        }
    }

    fun addToCart(product: Product) {
        viewModelScope.launch {
            repo.addCartItem(CartItem(productId=product.id, name=product.name, price=product.price, qty=1))
        }
    }

    suspend fun getCart(): List<CartItem> = withContext(Dispatchers.IO) {
        repo.getCartItems()
    }

    fun clearCart() {
        viewModelScope.launch { repo.clearCart() }
    }

    fun checkout(total: Long, paymentMethod: String, itemsJson: String) {
        viewModelScope.launch {
            val tx = TransactionEntity(datetime=System.currentTimeMillis(), total=total, paymentMethod=paymentMethod, itemsJson=itemsJson)
            repo.addTransaction(tx)
            repo.clearCart()
        }
    }
}
