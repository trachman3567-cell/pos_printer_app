package com.example.posprinter.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun all(): Flow<List<Product>>

    @Insert
    suspend fun insert(p: Product)
}
