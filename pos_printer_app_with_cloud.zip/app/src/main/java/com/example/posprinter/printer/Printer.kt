package com.example.posprinter.printer

interface Printer {
    val id: String
    val name: String
    suspend fun connect(): Boolean
    suspend fun disconnect()
    suspend fun printRaw(bytes: ByteArray): Boolean
    suspend fun printReceipt(bytesList: List<ByteArray>): Boolean
    suspend fun status(): PrinterStatus
    suspend fun isConnected(): Boolean
}

data class PrinterStatus(val online: Boolean, val paperOut: Boolean? = null, val errorMessage: String? = null)
