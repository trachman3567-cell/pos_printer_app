package com.example.posprinter.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun allCart(): List<CartItem>

    @Insert
    suspend fun insert(item: CartItem)

    @Query("DELETE FROM cart_items")
    suspend fun clear()
}
