package com.example.posprinter.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val datetime: Long,
    val total: Long,
    val paymentMethod: String,
    val itemsJson: String
)
