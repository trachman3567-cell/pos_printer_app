package com.example.posprinter

import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.coroutines.*
import com.example.posprinter.printer.*

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etIp = findViewById<EditText>(R.id.et_ip)
        val etPort = findViewById<EditText>(R.id.et_port)
        val btnConnect = findViewById<Button>(R.id.btn_connect)
        val tvStatus = findViewById<TextView>(R.id.tv_status)

        etPort.setText("9100")
        btnConnect.setOnClickListener {
            val ip = etIp.text.toString().trim()
            val port = etPort.text.toString().toIntOrNull() ?: 9100
            if (ip.isEmpty()) {
                tvStatus.text = "Status: masukkan IP printer"
                return@setOnClickListener
            }
            tvStatus.text = "Status: connecting..."
            scope.launch {
                val printer = RawTcpPrinter("p1", "Printer LAN", ip, port)
                val ok = printer.connect()
                if (!ok) {
                    tvStatus.text = "Status: gagal konek ke $ip:$port"
                    return@launch
                }
                tvStatus.text = "Status: connected, printing..."
                // Build simple receipt
                val parts = mutableListOf<ByteArray>()
                parts += EscPos.INIT
                parts += EscPos.alignCenter()
                parts += EscPos.boldOn()
                parts += EscPos.text("TOKO MAJU JAYA\n")
                parts += EscPos.boldOff()
                parts += EscPos.LF
                parts += EscPos.alignLeft()
                parts += EscPos.text("Nasi Goreng   15.000\n")
                parts += EscPos.text("Es Teh         5.000\n")
                parts += EscPos.LF
                // optional logo (if placed in assets/logo.png)
                try {
                    val ais = assets.open("logo.png")
                    val bmp = BitmapFactory.decodeStream(ais)
                    val logoCmd = BitmapToEscPos.toRasterCommand(bmp, maxWidthPx = 384)
                    parts += logoCmd
                    parts += EscPos.LF
                } catch (e: Exception) {
                    // ignore if no logo
                }
                parts += EscPos.CUT
                val printed = printer.printReceipt(parts)
                if (printed) {
                    tvStatus.text = "Status: print success"
                } else {
                    tvStatus.text = "Status: print failed"
                }
                printer.disconnect()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
