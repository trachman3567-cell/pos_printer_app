package com.example.posprinter.printer

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

object BitmapToEscPos {
    fun toRasterCommand(bitmap: Bitmap, maxWidthPx: Int): ByteArray {
        val scale = maxWidthPx.toFloat() / bitmap.width.toFloat()
        val scaled = Bitmap.createScaledBitmap(bitmap, maxWidthPx, (bitmap.height * scale).toInt(), true)
        val width = scaled.width
        val height = scaled.height
        val bytesPerRow = (width + 7) / 8

        val imageBaos = ByteArrayOutputStream()
        for (y in 0 until height) {
            for (xByte in 0 until bytesPerRow) {
                var v = 0
                for (bit in 0..7) {
                    val x = xByte * 8 + bit
                    val pixel = if (x < width) scaled.getPixel(x, y) else -1
                    val luminance = if (pixel == -1) 255 else {
                        val r = (pixel shr 16) and 0xFF
                        val g = (pixel shr 8) and 0xFF
                        val b = pixel and 0xFF
                        (0.299*r + 0.587*g + 0.114*b).toInt()
                    }
                    if (luminance < 127) {
                        v = v or (1 shl (7 - bit))
                    }
                }
                imageBaos.write(v)
            }
        }
        val imageData = imageBaos.toByteArray()
        val m: Byte = 0x00
        val xL = (bytesPerRow and 0xFF).toByte()
        val xH = ((bytesPerRow shr 8) and 0xFF).toByte()
        val yL = (height and 0xFF).toByte()
        val yH = ((height shr 8) and 0xFF).toByte()
        val header = byteArrayOf(0x1D, 0x76, 0x30, m, xL, xH, yL, yH)
        return header + imageData
    }
}
