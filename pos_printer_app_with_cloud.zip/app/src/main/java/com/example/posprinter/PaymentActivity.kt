package com.example.posprinter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import com.example.posprinter.viewmodel.PosViewModel
import kotlinx.coroutines.*
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.posprinter.printer.EscPos
import com.example.posprinter.printer.RawTcpPrinter
import com.example.posprinter.data.CartItem
import com.google.gson.Gson

class PaymentActivity : AppCompatActivity() {
    private val vm: PosViewModel by viewModels()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)
        val etCash = findViewById<EditText>(R.id.et_cash)
        val tvDue = findViewById<TextView>(R.id.tv_due)
        val btnPay = findViewById<Button>(R.id.btn_pay_confirm)

        scope.launch {
            val items = vm.getCart()
            val total = items.sumOf { it.price * it.qty }
            tvDue.text = "Total: " + total
            btnPay.setOnClickListener {
                val cash = etCash.text.toString().toLongOrNull() ?: 0L
                if (cash < total) {
                    tvDue.text = "Uang kurang: " + (total - cash)
                    return@setOnClickListener
                }
                val change = cash - total
                // build receipt and print
                scope.launch {
                    val parts = mutableListOf<ByteArray>()
                    parts += EscPos.INIT
                    parts += EscPos.alignCenter()
                    parts += EscPos.text("TOKO MAJU JAYA\n")
                    parts += EscPos.alignLeft()
                    for (it in items) {
                        parts += EscPos.text("${'$'}{it.name}  x${'$'}{it.qty}  ${'$'}{it.price * it.qty}\n")
                    }
                    parts += EscPos.text("TOTAL: ${'$'}{total}\n")
                    parts += EscPos.text("CASH: ${'$'}{cash}\n")
                    parts += EscPos.text("CHANGE: ${'$'}{change}\n")
                    parts += EscPos.CUT
                    val ip = "192.168.1.50"
                    val printer = RawTcpPrinter("p1","printer", ip, 9100)
                    val ok = printer.printReceipt(parts)
                    if (ok) {
                        // record transaction
                        val gson = Gson()
                        val itemsJson = gson.toJson(items)
                        vm.checkout(total, "CASH", itemsJson)
                        finish()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
