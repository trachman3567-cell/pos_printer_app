package com.example.posprinter.repo

import android.content.Context
import com.example.posprinter.data.AppDatabase
import com.example.posprinter.data.Product
import com.example.posprinter.data.CartItem
import com.example.posprinter.data.TransactionEntity
import kotlinx.coroutines.flow.Flow

class PosRepository(context: Context) {
    private val db = AppDatabase.get(context)
    val products: Flow<List<Product>> = db.productDao().all()

    suspend fun addProduct(p: Product) = db.productDao().insert(p)
    suspend fun addCartItem(item: CartItem) = db.cartDao().insert(item)
    suspend fun clearCart() = db.cartDao().clear()
    suspend fun getCartItems() = db.cartDao().allCart()
    suspend fun addTransaction(tx: TransactionEntity) = db.transactionDao().insert(tx)
    suspend fun getTransactions() = db.transactionDao().all()
}
