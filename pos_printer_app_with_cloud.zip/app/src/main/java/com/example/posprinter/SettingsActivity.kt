package com.example.posprinter

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import com.example.posprinter.cloud.CloudSync
import com.example.posprinter.cloud.DriveBackup
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import com.google.android.gms.auth.api.signin.GoogleSignIn

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = PreferenceManager.getDefaultSharedPreferences(this)

        val swAutoCut = findViewById<Switch>(R.id.sw_auto_cut)
        val swKitchen = findViewById<Switch>(R.id.sw_kitchen_mode)
        val etIp = findViewById<EditText>(R.id.et_printer_ip)
        val etPort = findViewById<EditText>(R.id.et_printer_port)
        val btnSave = findViewById<Button>(R.id.btn_save_settings)

        swAutoCut.isChecked = prefs.getBoolean("pref_auto_cut", true)
        swKitchen.isChecked = prefs.getBoolean("pref_kitchen_mode", false)
        etIp.setText(prefs.getString("pref_printer_ip", "192.168.1.50"))
        etPort.setText(prefs.getInt("pref_printer_port", 9100).toString())

        btnSave.setOnClickListener {
            val editor = prefs.edit()
            editor.putBoolean("pref_auto_cut", swAutoCut.isChecked)
            editor.putBoolean("pref_kitchen_mode", swKitchen.isChecked)
            editor.putString("pref_printer_ip", etIp.text.toString().trim())
            editor.putInt("pref_printer_port", etPort.text.toString().toIntOrNull() ?: 9100)
            editor.apply()
            finish()
        }

        val swFirebase = findViewById<Switch>(R.id.sw_firebase_sync)
        swFirebase.isChecked = prefs.getBoolean("pref_firebase_sync", false)
        swFirebase.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("pref_firebase_sync", checked).apply()
            if (checked) {
                CloudSync.init(this)
            }
        }

        val btnDrive = findViewById<Button>(R.id.btn_drive_backup)
        btnDrive.setOnClickListener {
            // start Google Sign-In flow
            val client = DriveBackup.getSignInClient(this)
            startActivityForResult(client.signInIntent, 9001)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9001 && resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(Exception::class.java)
                if (account != null) {
                    // Prepare a simple DB export (for demo: export products as CSV)
                    val db = com.example.posprinter.data.AppDatabase.get(this)
                    GlobalScope.launch {
                        val products = db.productDao().all().firstOrNull() ?: emptyList()
                        val csv = StringBuilder()
                        csv.append("sku,name,price,stock\n")
                        for (p in products) csv.append("${p.sku},${p.name},${p.price},${p.stock}\n")
                        val ok = DriveBackup.uploadFile(account, "pos_products_backup.csv", csv.toString().toByteArray())
                        // In production, notify user of success/failure on main thread.
                    }
                }
            } catch (e: Exception) { e.printStackTrace() }
        }
    }
}
